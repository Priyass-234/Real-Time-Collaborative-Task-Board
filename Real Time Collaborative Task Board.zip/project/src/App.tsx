import React, { useEffect, useState, useCallback } from 'react';
import { useBoardStore } from './store/boardStore';
import { useUserStore } from './store/userStore';
import { initSocket, disconnectSocket, getSocket } from './services/socket';
import Header from './components/Header';
import Board from './components/Board/Board';
import UserPresence from './components/UserPresence';
import Login from './components/Login';
import Reconnecting from './components/Reconnecting';
import { User, Board as BoardType } from './types';

function App() {
  const { setIsConnected, setBoard } = useBoardStore();
  const { currentUser, addUser, removeUser, setUsers } = useUserStore();
  const [initialized, setInitialized] = useState(false);
  
  // Handle socket connection
  const setupSocket = useCallback(() => {
    const socket = initSocket(
      // onConnect callback
      () => {
        setIsConnected(true);
      },
      // onDisconnect callback
      () => {
        setIsConnected(false);
      }
    );
    
    // Setup socket event listeners
    socket.on('board-update', (board: BoardType) => {
      setBoard(board);
    });
    
    socket.on('user-joined', (user: User) => {
      addUser(user);
    });
    
    socket.on('user-left', (userId: string) => {
      removeUser(userId);
    });
    
    socket.on('users-update', (users: User[]) => {
      setUsers(users);
    });
    
    return () => {
      socket.off('board-update');
      socket.off('user-joined');
      socket.off('user-left');
      socket.off('users-update');
      disconnectSocket();
    };
  }, [setIsConnected, setBoard, addUser, removeUser, setUsers]);
  
  // Initialize socket on mount
  useEffect(() => {
    if (currentUser) {
      const cleanup = setupSocket();
      setInitialized(true);
      return cleanup;
    }
  }, [currentUser, setupSocket]);
  
  // Function to handle reconnection attempts
  const handleRetryConnect = useCallback(() => {
    if (!getSocket().connected) {
      disconnectSocket();
      setupSocket();
    }
  }, [setupSocket]);
  
  if (!currentUser) {
    return <Login />;
  }
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto p-4">
        <UserPresence />
        <Board />
      </main>
      
      <Reconnecting 
        isConnected={useBoardStore.getState().isConnected} 
        onRetryConnect={handleRetryConnect} 
      />
    </div>
  );
}

export default App;