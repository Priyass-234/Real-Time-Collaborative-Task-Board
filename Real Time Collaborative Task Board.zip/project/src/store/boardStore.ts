import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { Board, Column, Task, User, DropResult } from '../types';
import { emitBoardUpdate } from '../services/socket';

const DEFAULT_COLUMNS = [
  { id: 'column-1', title: 'To Do', taskIds: [] },
  { id: 'column-2', title: 'In Progress', taskIds: [] },
  { id: 'column-3', title: 'Done', taskIds: [] },
];

const INITIAL_BOARD: Board = {
  tasks: {},
  columns: DEFAULT_COLUMNS.reduce((acc, column) => {
    acc[column.id] = column;
    return acc;
  }, {} as Record<string, Column>),
  columnOrder: DEFAULT_COLUMNS.map(column => column.id),
};

interface BoardState {
  board: Board;
  isConnected: boolean;
  users: User[];
  currentUser: User | null;
  
  // Actions
  setBoard: (board: Board) => void;
  setIsConnected: (isConnected: boolean) => void;
  setUsers: (users: User[]) => void;
  setCurrentUser: (user: User) => void;
  
  // Board operations
  addTask: (columnId: string, title: string, description?: string) => void;
  updateTask: (taskId: string, title: string, description?: string) => void;
  deleteTask: (taskId: string) => void;
  addColumn: (title: string) => void;
  updateColumn: (columnId: string, title: string) => void;
  deleteColumn: (columnId: string) => void;
  handleDragEnd: (result: DropResult) => void;
  reorderColumns: (startIndex: number, endIndex: number) => void;
}

export const useBoardStore = create<BoardState>((set, get) => ({
  board: INITIAL_BOARD,
  isConnected: false,
  users: [],
  currentUser: null,
  
  setBoard: (board) => set({ board }),
  setIsConnected: (isConnected) => set({ isConnected }),
  setUsers: (users) => set({ users }),
  setCurrentUser: (user) => set({ currentUser: user }),
  
  addTask: (columnId, title, description) => {
    const { board } = get();
    const newTaskId = uuidv4();
    
    const newTask: Task = {
      id: newTaskId,
      title,
      description: description || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    const column = board.columns[columnId];
    const newTaskIds = [...column.taskIds, newTaskId];
    
    const newBoard = {
      ...board,
      tasks: {
        ...board.tasks,
        [newTaskId]: newTask,
      },
      columns: {
        ...board.columns,
        [columnId]: {
          ...column,
          taskIds: newTaskIds,
        },
      },
    };
    
    set({ board: newBoard });
    emitBoardUpdate(newBoard);
  },
  
  updateTask: (taskId, title, description) => {
    const { board } = get();
    
    if (!board.tasks[taskId]) return;
    
    const updatedTask = {
      ...board.tasks[taskId],
      title,
      description: description || board.tasks[taskId].description,
      updatedAt: new Date().toISOString(),
    };
    
    const newBoard = {
      ...board,
      tasks: {
        ...board.tasks,
        [taskId]: updatedTask,
      },
    };
    
    set({ board: newBoard });
    emitBoardUpdate(newBoard);
  },
  
  deleteTask: (taskId) => {
    const { board } = get();
    
    if (!board.tasks[taskId]) return;
    
    // Find which column contains this task
    let columnId = '';
    Object.entries(board.columns).forEach(([id, column]) => {
      if (column.taskIds.includes(taskId)) {
        columnId = id;
      }
    });
    
    if (!columnId) return;
    
    // Create new tasks object without the deleted task
    const { [taskId]: deletedTask, ...remainingTasks } = board.tasks;
    
    // Update the column's taskIds
    const column = board.columns[columnId];
    const newTaskIds = column.taskIds.filter(id => id !== taskId);
    
    const newBoard = {
      ...board,
      tasks: remainingTasks,
      columns: {
        ...board.columns,
        [columnId]: {
          ...column,
          taskIds: newTaskIds,
        },
      },
    };
    
    set({ board: newBoard });
    emitBoardUpdate(newBoard);
  },
  
  addColumn: (title) => {
    const { board } = get();
    const newColumnId = uuidv4();
    
    const newColumn: Column = {
      id: newColumnId,
      title,
      taskIds: [],
    };
    
    const newBoard = {
      ...board,
      columns: {
        ...board.columns,
        [newColumnId]: newColumn,
      },
      columnOrder: [...board.columnOrder, newColumnId],
    };
    
    set({ board: newBoard });
    emitBoardUpdate(newBoard);
  },
  
  updateColumn: (columnId, title) => {
    const { board } = get();
    
    if (!board.columns[columnId]) return;
    
    const newBoard = {
      ...board,
      columns: {
        ...board.columns,
        [columnId]: {
          ...board.columns[columnId],
          title,
        },
      },
    };
    
    set({ board: newBoard });
    emitBoardUpdate(newBoard);
  },
  
  deleteColumn: (columnId) => {
    const { board } = get();
    
    if (!board.columns[columnId]) return;
    
    // Get all task IDs in this column
    const taskIdsToDelete = board.columns[columnId].taskIds;
    
    // Create new tasks object without the tasks in this column
    const newTasks = { ...board.tasks };
    taskIdsToDelete.forEach(taskId => {
      delete newTasks[taskId];
    });
    
    // Create new columns object without this column
    const { [columnId]: deletedColumn, ...remainingColumns } = board.columns;
    
    // Update columnOrder
    const newColumnOrder = board.columnOrder.filter(id => id !== columnId);
    
    const newBoard = {
      tasks: newTasks,
      columns: remainingColumns,
      columnOrder: newColumnOrder,
    };
    
    set({ board: newBoard });
    emitBoardUpdate(newBoard);
  },
  
  handleDragEnd: (result) => {
    const { source, destination } = result;
    
    // Dropped outside a droppable area
    if (!destination) return;
    
    // No movement occurred
    if (
      source.droppableId === destination.droppableId &&
      source.index === destination.index
    ) {
      return;
    }
    
    const { board } = get();
    
    // Handle column reordering
    if (source.droppableId === 'column-list' && destination.droppableId === 'column-list') {
      const newColumnOrder = Array.from(board.columnOrder);
      const [movedColumnId] = newColumnOrder.splice(source.index, 1);
      newColumnOrder.splice(destination.index, 0, movedColumnId);
      
      const newBoard = {
        ...board,
        columnOrder: newColumnOrder,
      };
      
      set({ board: newBoard });
      emitBoardUpdate(newBoard);
      return;
    }
    
    // Handle task movement
    const sourceColumn = board.columns[source.droppableId];
    const destinationColumn = board.columns[destination.droppableId];
    
    // Moving within the same column
    if (sourceColumn.id === destinationColumn.id) {
      const newTaskIds = Array.from(sourceColumn.taskIds);
      const [movedTaskId] = newTaskIds.splice(source.index, 1);
      newTaskIds.splice(destination.index, 0, movedTaskId);
      
      const newBoard = {
        ...board,
        columns: {
          ...board.columns,
          [sourceColumn.id]: {
            ...sourceColumn,
            taskIds: newTaskIds,
          },
        },
      };
      
      set({ board: newBoard });
      emitBoardUpdate(newBoard);
      return;
    }
    
    // Moving to a different column
    const sourceTaskIds = Array.from(sourceColumn.taskIds);
    const [movedTaskId] = sourceTaskIds.splice(source.index, 1);
    
    const destinationTaskIds = Array.from(destinationColumn.taskIds);
    destinationTaskIds.splice(destination.index, 0, movedTaskId);
    
    const newBoard = {
      ...board,
      columns: {
        ...board.columns,
        [sourceColumn.id]: {
          ...sourceColumn,
          taskIds: sourceTaskIds,
        },
        [destinationColumn.id]: {
          ...destinationColumn,
          taskIds: destinationTaskIds,
        },
      },
    };
    
    set({ board: newBoard });
    emitBoardUpdate(newBoard);
  },
  
  reorderColumns: (startIndex, endIndex) => {
    const { board } = get();
    const newColumnOrder = Array.from(board.columnOrder);
    const [removed] = newColumnOrder.splice(startIndex, 1);
    newColumnOrder.splice(endIndex, 0, removed);
    
    const newBoard = {
      ...board,
      columnOrder: newColumnOrder,
    };
    
    set({ board: newBoard });
    emitBoardUpdate(newBoard);
  },
}));