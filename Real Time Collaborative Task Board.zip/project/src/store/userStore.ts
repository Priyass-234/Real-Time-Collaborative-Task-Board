import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { User } from '../types';
import { emitUserJoin, emitUserLeave } from '../services/socket';

// Generate a random color from a predefined set of colors
const COLORS = [
  '#3498db', // Blue
  '#9b59b6', // Purple
  '#e74c3c', // Red
  '#f39c12', // Orange
  '#1abc9c', // Teal
  '#2ecc71', // Green
];

const getRandomColor = () => {
  const randomIndex = Math.floor(Math.random() * COLORS.length);
  return COLORS[randomIndex];
};

interface UserState {
  currentUser: User | null;
  users: User[];
  initUser: (name?: string) => void;
  setUsers: (users: User[]) => void;
  addUser: (user: User) => void;
  removeUser: (userId: string) => void;
  updateUserActivity: (userId: string, isActive: boolean) => void;
}

export const useUserStore = create<UserState>((set, get) => ({
  currentUser: null,
  users: [],
  
  initUser: (name) => {
    const username = name || `User-${Math.floor(Math.random() * 1000)}`;
    const newUser: User = {
      id: uuidv4(),
      name: username,
      isActive: true,
      color: getRandomColor(),
    };
    
    set({ currentUser: newUser });
    
    // Add user to the list and emit join event
    get().addUser(newUser);
    emitUserJoin(newUser);
    
    // Set up cleanup on page unload
    window.addEventListener('beforeunload', () => {
      if (get().currentUser) {
        emitUserLeave(get().currentUser.id);
      }
    });
  },
  
  setUsers: (users) => set({ users }),
  
  addUser: (user) => {
    set(state => {
      // Don't add if user already exists
      if (state.users.some(u => u.id === user.id)) {
        return state;
      }
      
      return {
        users: [...state.users, user],
      };
    });
  },
  
  removeUser: (userId) => {
    set(state => ({
      users: state.users.filter(user => user.id !== userId),
    }));
  },
  
  updateUserActivity: (userId, isActive) => {
    set(state => ({
      users: state.users.map(user => 
        user.id === userId 
          ? { ...user, isActive } 
          : user
      ),
    }));
  },
}));