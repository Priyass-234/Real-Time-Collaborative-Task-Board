import { io, Socket } from 'socket.io-client';
import { Board, User } from '../types';

// Create a mock socket implementation
class MockSocket {
  private listeners: { [event: string]: Function[] } = {};
  public id = 'mock-socket-' + Math.random().toString(36).substr(2, 9);
  
  on(event: string, callback: Function) {
    if (!this.listeners[event]) {
      this.listeners[event] = [];
    }
    this.listeners[event].push(callback);
    
    // Simulate immediate connection
    if (event === 'connect') {
      setTimeout(() => callback(), 100);
    }
  }
  
  emit(event: string, ...args: any[]) {
    console.log(`Mock Socket Emit: ${event}`, ...args);
    // Simulate event echo for testing
    if (this.listeners[event]) {
      this.listeners[event].forEach(callback => setTimeout(() => callback(...args), 100));
    }
  }
  
  disconnect() {
    if (this.listeners['disconnect']) {
      this.listeners['disconnect'].forEach(callback => callback());
    }
    this.listeners = {};
  }
}

let socket: any; // Using any to accommodate both real Socket and MockSocket

// Simulate other users for demo purposes
const DEMO_USERS = [
  { id: 'user1', name: 'Alice', isActive: true, color: '#3498db' },
  { id: 'user2', name: 'Bob', isActive: true, color: '#2ecc71' },
  { id: 'user3', name: 'Charlie', isActive: false, color: '#e74c3c' },
  { id: 'user4', name: 'Diana', isActive: true, color: '#f39c12' },
];

export const initSocket = (onConnect: () => void, onDisconnect: () => void): Socket => {
  if (!socket) {
    // Create mock socket instead of real connection
    socket = new MockSocket();

    socket.on('connect', () => {
      console.log('Mock socket connected:', socket.id);
      onConnect();
      
      // Simulate other users joining after a delay
      setTimeout(() => {
        DEMO_USERS.forEach((user, index) => {
          setTimeout(() => {
            socket.emit('user-joined', user);
          }, index * 1000); // Stagger user joins
        });
        
        // Simulate users going active/inactive
        setInterval(() => {
          const randomUser = DEMO_USERS[Math.floor(Math.random() * DEMO_USERS.length)];
          randomUser.isActive = !randomUser.isActive;
          socket.emit('users-update', [randomUser, ...DEMO_USERS.filter(u => u.id !== randomUser.id)]);
        }, 5000);
      }, 2000);
    });

    socket.on('disconnect', () => {
      console.log('Socket disconnected');
      onDisconnect();
    });
  }

  return socket as Socket;
};

export const disconnectSocket = (): void => {
  if (socket) {
    socket.disconnect();
  }
};

// Mock implementations that would normally communicate with a server
export const emitBoardUpdate = (board: Board): void => {
  console.log('Emitting board update:', board);
  
  setTimeout(() => {
    if (socket) {
      socket.emit('board-update', board);
    }
  }, 100);
};

export const emitUserJoin = (user: User): void => {
  console.log('User joined:', user);
  
  setTimeout(() => {
    if (socket) {
      socket.emit('user-joined', user);
      // Send initial users list including demo users
      socket.emit('users-update', [user, ...DEMO_USERS]);
    }
  }, 100);
};

export const emitUserLeave = (userId: string): void => {
  console.log('User left:', userId);
  if (socket) {
    socket.emit('user-leave', userId);
  }
};

export const getSocket = (): Socket => {
  if (!socket) {
    throw new Error('Socket not initialized. Call initSocket first.');
  }
  return socket as Socket;
};