import React, { useState, useRef } from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Column as ColumnType, Task as TaskType } from '../../types';
import Task from '../Task/Task';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { Edit, Trash2, X, Check, Plus } from 'lucide-react';

interface ColumnProps {
  column: ColumnType;
  tasks: TaskType[];
  updateColumn: (id: string, title: string) => void;
  deleteColumn: (id: string) => void;
  addTask: (columnId: string, title: string, description?: string) => void;
  updateTask: (id: string, title: string, description?: string) => void;
  deleteTask: (id: string) => void;
}

const Column: React.FC<ColumnProps> = ({
  column,
  tasks,
  updateColumn,
  deleteColumn,
  addTask,
  updateTask,
  deleteTask,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [title, setTitle] = useState(column.title);
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskDescription, setNewTaskDescription] = useState('');
  
  const titleInputRef = useRef<HTMLInputElement>(null);
  const newTaskInputRef = useRef<HTMLInputElement>(null);
  
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: column.id });
  
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };
  
  const handleEdit = () => {
    setIsEditing(true);
    // Focus the title input after rendering
    setTimeout(() => {
      titleInputRef.current?.focus();
    }, 0);
  };
  
  const handleSave = () => {
    if (title.trim()) {
      updateColumn(column.id, title);
      setIsEditing(false);
    }
  };
  
  const handleCancel = () => {
    setTitle(column.title);
    setIsEditing(false);
  };
  
  const handleAddTask = () => {
    setIsAddingTask(true);
    // Focus the new task input after rendering
    setTimeout(() => {
      newTaskInputRef.current?.focus();
    }, 0);
  };
  
  const handleSaveTask = () => {
    if (newTaskTitle.trim()) {
      addTask(column.id, newTaskTitle, newTaskDescription);
      setNewTaskTitle('');
      setNewTaskDescription('');
      setIsAddingTask(false);
    }
  };
  
  const handleCancelAddTask = () => {
    setNewTaskTitle('');
    setNewTaskDescription('');
    setIsAddingTask(false);
  };
  
  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`
        bg-gray-100 rounded-lg shadow w-72 flex flex-col
        ${isDragging ? 'shadow-lg' : ''}
      `}
    >
      {/* Column Header */}
      <div 
        className="p-3 bg-gray-200 rounded-t-lg"
        {...attributes}
        {...listeners}
      >
        {isEditing ? (
          <div className="flex items-center">
            <input
              ref={titleInputRef}
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="flex-1 p-1 border border-gray-300 rounded focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
            
            <div className="flex ml-2">
              <button
                onClick={handleCancel}
                className="p-1 text-gray-500 hover:text-gray-700"
                aria-label="Cancel"
              >
                <X size={16} />
              </button>
              <button
                onClick={handleSave}
                className="p-1 text-green-500 hover:text-green-700"
                aria-label="Save"
              >
                <Check size={16} />
              </button>
            </div>
          </div>
        ) : (
          <div className="flex justify-between items-center">
            <h2 className="font-semibold text-gray-700">{column.title}</h2>
            
            <div className="flex">
              <button
                onClick={handleEdit}
                className="p-1 text-gray-500 hover:text-gray-700"
                aria-label="Edit column"
              >
                <Edit size={16} />
              </button>
              
              <button
                onClick={() => deleteColumn(column.id)}
                className="p-1 text-gray-500 hover:text-red-600"
                aria-label="Delete column"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        )}
      </div>
      
      {/* Task List */}
      <div className="p-2 flex-grow overflow-y-auto max-h-[calc(100vh-240px)]">
        <SortableContext
          items={tasks.map(task => task.id)}
          strategy={verticalListSortingStrategy}
        >
          {tasks.map((task) => (
            <Task
              key={task.id}
              task={task}
              updateTask={updateTask}
              deleteTask={deleteTask}
            />
          ))}
        </SortableContext>
        
        {tasks.length === 0 && (
          <p className="text-gray-400 text-sm text-center my-4">
            No tasks yet
          </p>
        )}
      </div>
      
      {/* Add Task Form */}
      <div className="p-2 border-t border-gray-200">
        {isAddingTask ? (
          <div className="space-y-2">
            <input
              ref={newTaskInputRef}
              type="text"
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="Task title"
            />
            
            <textarea
              value={newTaskDescription}
              onChange={(e) => setNewTaskDescription(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              rows={2}
              placeholder="Description (optional)"
            />
            
            <div className="flex justify-end space-x-2">
              <button
                onClick={handleCancelAddTask}
                className="px-3 py-1 text-gray-500 hover:text-gray-700"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveTask}
                className="px-3 py-1 bg-indigo-600 text-white rounded hover:bg-indigo-700"
              >
                Add
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={handleAddTask}
            className="w-full flex items-center justify-center p-2 border border-dashed border-gray-300 rounded-lg text-gray-500 hover:text-indigo-600 hover:border-indigo-500 transition-colors"
          >
            <Plus size={16} className="mr-1" />
            Add Task
          </button>
        )}
      </div>
    </div>
  );
};

export default Column;