import React from 'react';
import { useUserStore } from '../store/userStore';
import { useBoardStore } from '../store/boardStore';
import { Users } from 'lucide-react';

const Header: React.FC = () => {
  const { users, currentUser } = useUserStore();
  const { isConnected } = useBoardStore();
  
  const activeUsers = users.filter(user => user.isActive);
  
  return (
    <header className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <h1 className="text-2xl font-bold">TaskBoard</h1>
          <div className="ml-4 bg-white/20 px-3 py-1 rounded-full text-sm flex items-center">
            {isConnected ? (
              <>
                <span className="h-2 w-2 rounded-full bg-green-400 mr-2"></span>
                Connected
              </>
            ) : (
              <>
                <span className="h-2 w-2 rounded-full bg-red-400 mr-2"></span>
                Disconnected
              </>
            )}
          </div>
        </div>
        
        <div className="flex items-center">
          <div className="mr-6 flex items-center">
            <Users size={18} className="mr-2" />
            <span>{activeUsers.length} online</span>
          </div>
          
          {currentUser && (
            <div 
              className="flex items-center bg-white/20 px-3 py-1 rounded-full"
              style={{ borderColor: currentUser.color }}
            >
              <div 
                className="h-4 w-4 rounded-full mr-2" 
                style={{ backgroundColor: currentUser.color }}
              ></div>
              <span className="text-sm font-medium">{currentUser.name}</span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;