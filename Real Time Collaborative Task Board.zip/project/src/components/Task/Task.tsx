import React, { useState, useRef } from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Task as TaskType } from '../../types';
import { Edit, Trash2, X, Check, MessageSquare } from 'lucide-react';

interface TaskProps {
  task: TaskType;
  updateTask: (id: string, title: string, description?: string) => void;
  deleteTask: (id: string) => void;
}

const Task: React.FC<TaskProps> = ({ task, updateTask, deleteTask }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [showDescription, setShowDescription] = useState(false);
  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description || '');
  
  const titleInputRef = useRef<HTMLInputElement>(null);
  
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: task.id });
  
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    zIndex: isDragging ? 10 : 1,
  };
  
  const handleEdit = () => {
    setIsEditing(true);
    // Focus the title input after rendering
    setTimeout(() => {
      titleInputRef.current?.focus();
    }, 0);
  };
  
  const handleCancel = () => {
    setTitle(task.title);
    setDescription(task.description || '');
    setIsEditing(false);
  };
  
  const handleSave = () => {
    if (title.trim()) {
      updateTask(task.id, title, description);
      setIsEditing(false);
    }
  };
  
  const formattedDate = new Date(task.updatedAt).toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
  
  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`
        bg-white rounded-lg shadow-sm border border-gray-200
        p-3 mb-2 select-none
        ${isDragging ? 'shadow-md' : ''}
      `}
    >
      {isEditing ? (
        <div className="space-y-2">
          <input
            ref={titleInputRef}
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            placeholder="Task title"
          />
          
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            rows={3}
            placeholder="Add description (optional)"
          />
          
          <div className="flex justify-end space-x-2">
            <button
              onClick={handleCancel}
              className="p-1 text-gray-500 hover:text-gray-700"
              aria-label="Cancel"
            >
              <X size={16} />
            </button>
            <button
              onClick={handleSave}
              className="p-1 text-green-500 hover:text-green-700"
              aria-label="Save"
            >
              <Check size={16} />
            </button>
          </div>
        </div>
      ) : (
        <div>
          <div 
            className="flex justify-between items-start"
            {...attributes}
            {...listeners}
          >
            <h3 className="font-medium text-gray-800">{task.title}</h3>
            
            <div className="flex space-x-1">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleEdit();
                }}
                className="p-1 text-gray-400 hover:text-gray-600"
                aria-label="Edit task"
              >
                <Edit size={14} />
              </button>
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  deleteTask(task.id);
                }}
                className="p-1 text-gray-400 hover:text-red-600"
                aria-label="Delete task"
              >
                <Trash2 size={14} />
              </button>
            </div>
          </div>
          
          {task.description && (
            <div className="mt-2">
              <button
                onClick={() => setShowDescription(!showDescription)}
                className="flex items-center text-xs text-gray-500 hover:text-indigo-600"
              >
                <MessageSquare size={12} className="mr-1" />
                {showDescription ? 'Hide description' : 'Show description'}
              </button>
              
              {showDescription && (
                <p className="mt-2 text-sm text-gray-600 whitespace-pre-wrap">
                  {task.description}
                </p>
              )}
            </div>
          )}
          
          <div className="mt-2 text-xs text-gray-400">
            Updated: {formattedDate}
          </div>
        </div>
      )}
    </div>
  );
};

export default Task;