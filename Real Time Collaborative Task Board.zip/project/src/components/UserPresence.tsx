import React from 'react';
import { useUserStore } from '../store/userStore';

const UserPresence: React.FC = () => {
  const { users, currentUser } = useUserStore();
  
  const sortedUsers = [...users].sort((a, b) => {
    // Current user always first
    if (a.id === currentUser?.id) return -1;
    if (b.id === currentUser?.id) return 1;
    
    // Then active users
    if (a.isActive && !b.isActive) return -1;
    if (!a.isActive && b.isActive) return 1;
    
    // Alphabetical by name
    return a.name.localeCompare(b.name);
  });
  
  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-6">
      <h2 className="text-lg font-semibold mb-3">Active Users</h2>
      
      <div className="flex flex-wrap gap-2">
        {sortedUsers.map(user => (
          <div 
            key={user.id}
            className={`
              px-3 py-1 rounded-full text-sm flex items-center
              ${user.isActive ? 'bg-gray-100' : 'bg-gray-50 text-gray-400'}
              ${user.id === currentUser?.id ? 'border-2' : 'border'}
            `}
            style={{ 
              borderColor: user.color,
              opacity: user.isActive ? 1 : 0.6 
            }}
          >
            <div 
              className="h-3 w-3 rounded-full mr-2" 
              style={{ backgroundColor: user.color }}
            ></div>
            <span>
              {user.name}
              {user.id === currentUser?.id ? ' (You)' : ''}
            </span>
          </div>
        ))}
        
        {users.length === 0 && (
          <p className="text-gray-500 text-sm">No other users connected</p>
        )}
      </div>
    </div>
  );
};

export default UserPresence;