import React, { useEffect, useState } from 'react';

interface ReconnectingProps {
  isConnected: boolean;
  onRetryConnect: () => void;
}

const Reconnecting: React.FC<ReconnectingProps> = ({ isConnected, onRetryConnect }) => {
  const [showReconnect, setShowReconnect] = useState(false);
  const [countdown, setCountdown] = useState(5);
  
  useEffect(() => {
    if (!isConnected) {
      // Show reconnecting message after a brief delay to avoid flashing
      const timer = setTimeout(() => {
        setShowReconnect(true);
        setCountdown(5);
      }, 1000);
      
      return () => clearTimeout(timer);
    } else {
      setShowReconnect(false);
    }
  }, [isConnected]);
  
  useEffect(() => {
    if (showReconnect && countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown(prev => prev - 1);
      }, 1000);
      
      return () => clearTimeout(timer);
    } else if (showReconnect && countdown === 0) {
      onRetryConnect();
      setCountdown(5);
    }
  }, [showReconnect, countdown, onRetryConnect]);
  
  if (!showReconnect) return null;
  
  return (
    <div className="fixed inset-x-0 bottom-0 z-50">
      <div className="bg-amber-100 border-t border-amber-300 p-3">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-amber-500 rounded-full animate-pulse mr-2"></div>
            <span className="text-amber-800">
              Connection lost. Attempting to reconnect in {countdown} seconds...
            </span>
          </div>
          <button
            onClick={() => {
              onRetryConnect();
              setCountdown(5);
            }}
            className="px-3 py-1 bg-amber-600 text-white rounded-md hover:bg-amber-700 transition"
          >
            Retry Now
          </button>
        </div>
      </div>
    </div>
  );
};

export default Reconnecting;