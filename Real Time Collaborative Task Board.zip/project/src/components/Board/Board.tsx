import React, { useState } from 'react';
import {
  DndContext,
  DragOverlay,
  closestCorners,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  horizontalListSortingStrategy,
} from '@dnd-kit/sortable';
import { restrictToWindowEdges } from '@dnd-kit/modifiers';
import { useBoardStore } from '../../store/boardStore';
import Column from '../Column/Column';
import Task from '../Task/Task';
import { Plus } from 'lucide-react';
import { Task as TaskType } from '../../types';

const Board: React.FC = () => {
  const {
    board,
    addTask,
    updateTask,
    deleteTask,
    addColumn,
    updateColumn,
    deleteColumn,
    handleDragEnd,
  } = useBoardStore();
  
  const [activeId, setActiveId] = useState<string | null>(null);
  const [activeTask, setActiveTask] = useState<TaskType | null>(null);
  const [isAddingColumn, setIsAddingColumn] = useState(false);
  const [newColumnTitle, setNewColumnTitle] = useState('');
  
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 5,
      },
    }),
    useSensor(KeyboardSensor)
  );
  
  const handleDragStart = (event: any) => {
    const { active } = event;
    setActiveId(active.id);
    
    // If dragging a task, store the task data
    const task = Object.values(board.tasks).find(task => task.id === active.id);
    if (task) {
      setActiveTask(task);
    }
  };
  
  const onDragEnd = (event: any) => {
    const { active, over } = event;
    
    if (over) {
      handleDragEnd({
        source: {
          droppableId: active.data.current?.sortable.containerId || 'column-list',
          index: active.data.current?.sortable.index,
        },
        destination: {
          droppableId: over.data.current?.sortable.containerId || 'column-list',
          index: over.data.current?.sortable.index,
        },
      });
    }
    
    setActiveId(null);
    setActiveTask(null);
  };
  
  const handleAddColumn = () => {
    if (newColumnTitle.trim()) {
      addColumn(newColumnTitle);
      setNewColumnTitle('');
      setIsAddingColumn(false);
    }
  };
  
  return (
    <div className="p-4">
      <DndContext
        sensors={sensors}
        collisionDetection={closestCorners}
        onDragStart={handleDragStart}
        onDragEnd={onDragEnd}
        modifiers={[restrictToWindowEdges]}
      >
        <div className="flex items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-800">Your Board</h2>
          
          {isAddingColumn ? (
            <div className="ml-4 flex">
              <input
                type="text"
                value={newColumnTitle}
                onChange={(e) => setNewColumnTitle(e.target.value)}
                className="border border-gray-300 rounded-l p-1 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                placeholder="Column title"
                autoFocus
              />
              <button
                onClick={handleAddColumn}
                className="bg-indigo-600 text-white px-3 py-1 rounded-r hover:bg-indigo-700"
              >
                Add
              </button>
              <button
                onClick={() => {
                  setNewColumnTitle('');
                  setIsAddingColumn(false);
                }}
                className="ml-2 text-gray-500 hover:text-gray-700"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              onClick={() => setIsAddingColumn(true)}
              className="ml-4 flex items-center text-indigo-600 hover:text-indigo-800"
            >
              <Plus size={16} className="mr-1" />
              Add Column
            </button>
          )}
        </div>
        
        <div className="flex space-x-4 overflow-x-auto pb-4">
          <SortableContext
            items={board.columnOrder}
            strategy={horizontalListSortingStrategy}
          >
            {board.columnOrder.map((columnId) => {
              const column = board.columns[columnId];
              const columnTasks = column.taskIds.map(
                (taskId) => board.tasks[taskId]
              ).filter(Boolean);
              
              return (
                <Column
                  key={column.id}
                  column={column}
                  tasks={columnTasks}
                  updateColumn={updateColumn}
                  deleteColumn={deleteColumn}
                  addTask={addTask}
                  updateTask={updateTask}
                  deleteTask={deleteTask}
                />
              );
            })}
          </SortableContext>
          
          {board.columnOrder.length === 0 && (
            <div className="flex items-center justify-center h-40 w-full">
              <div className="text-center text-gray-500">
                <p className="mb-2">Your board is empty!</p>
                <button
                  onClick={() => setIsAddingColumn(true)}
                  className="text-indigo-600 hover:text-indigo-800 flex items-center mx-auto"
                >
                  <Plus size={16} className="mr-1" />
                  Add your first column
                </button>
              </div>
            </div>
          )}
        </div>
        
        {/* Drag overlay for visual feedback during drag */}
        <DragOverlay>
          {activeId && activeTask && (
            <Task
              task={activeTask}
              updateTask={updateTask}
              deleteTask={deleteTask}
            />
          )}
        </DragOverlay>
      </DndContext>
    </div>
  );
};

export default Board;