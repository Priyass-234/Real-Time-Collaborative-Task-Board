import React, { useState } from 'react';
import { useUserStore } from '../store/userStore';

const Login: React.FC = () => {
  const { initUser } = useUserStore();
  const [username, setUsername] = useState('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    initUser(username.trim() || undefined);
  };
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-indigo-600 to-purple-600 p-4">
      <div className="bg-white rounded-lg shadow-xl p-8 w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">TaskBoard</h1>
          <p className="text-gray-600">Real-time collaborative task management</p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">
              Your Name
            </label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your name (or leave blank for random)"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>
          
          <button
            type="submit"
            className="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition duration-200 focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Enter Board
          </button>
        </form>
        
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>Changes you make will be visible to everyone in real-time</p>
        </div>
      </div>
    </div>
  );
};

export default Login;