# TaskBoard - Real-Time Collaborative Task Management 🚀

A modern, real-time collaborative task board application built with React and Socket.IO, enabling teams to manage tasks with live updates and seamless collaboration.

![TaskBoard Screenshot](https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)

## ✨ Key Features

- **Real-Time Collaboration** - See changes instantly across all connected users
- **Drag & Drop Interface** - Intuitive task and column management
- **User Presence** - Track active users and their status
- **Rich Task Management** - Create, edit, and organize tasks with descriptions
- **Column Customization** - Flexible board layout with reorderable columns
- **Responsive Design** - Works seamlessly across all devices
- **Auto-Reconnection** - Handles connection drops gracefully

## 🛠️ Built With

- **React 18** - Modern UI development
- **TypeScript** - Type-safe code
- **Socket.IO** - Real-time communication
- **Zustand** - State management
- **DND Kit** - Drag and drop functionality
- **Tailwind CSS** - Styling
- **Lucide React** - Beautiful icons
- **Vite** - Fast development and building

## 🚀 Getting Started

1. Clone the repository
```bash
git clone https://github.com/your-username/taskboard.git
cd taskboard
```

2. Install dependencies
```bash
npm install
```

3. Start the development server
```bash
npm run dev
```

4. Open your browser and visit `http://localhost:5173`

## 📱 Usage

1. Enter your name on the login screen
2. Create columns for your workflow (e.g., "To Do", "In Progress", "Done")
3. Add tasks to columns
4. Drag and drop tasks between columns
5. Watch as changes sync in real-time across all users

## 🏗️ Project Structure

```
src/
├── components/     # UI components
├── services/      # Socket handling
├── store/         # State management
├── types/         # TypeScript definitions
└── App.tsx        # Main application
```

## ⚡ Features in Detail

### Task Management
- Create, edit, and delete tasks
- Add detailed descriptions
- Track creation and update times
- Drag and drop between columns

### Column Organization
- Create custom columns
- Reorder columns via drag and drop
- Rename or delete columns
- Maintain task order within columns

### Real-Time Collaboration
- Instant updates across clients
- User presence indicators
- Connection status monitoring
- Automatic reconnection handling

### User Interface
- Clean, modern design
- Responsive layout
- Intuitive drag and drop
- Real-time status updates

## 🔧 Development

```bash
# Run development server
npm run dev

# Build for production
npm run build

# Run linter
npm run lint
```

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙌 Acknowledgments

- [React](https://reactjs.org/)
- [Socket.IO](https://socket.io/)
- [DND Kit](https://dndkit.com/)
- [Zustand](https://github.com/pmndrs/zustand)
- [Tailwind CSS](https://tailwindcss.com/)
- [Lucide Icons](https://lucide.dev/)